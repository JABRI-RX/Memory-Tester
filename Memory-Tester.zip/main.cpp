#include "imgui/imgui.h"
#include "imgui/imgui_impl_glfw.h"
#include "imgui/imgui_impl_opengl3.h"
#include <stdio.h>
#define GL_SILENCE_DEPRECATION
#include <iostream>

#include <GLFW/glfw3.h> // Will drag system OpenGL headers
#include "MemMan.h"
#include <string>
struct Vec3 {
    float x, y, z;
    Vec3(float X, float Y, float Z) :x(X), y(Y), z(Z) {}
};
struct Vec2 {
    float x, y;
    Vec2() { x = -1, y = -1; }
    Vec2(float X, float Y ) :x(X), y(Y){}
};
struct Matrix {
    float matrix[16];
    void print()
    {
        printf("[%f]\t[%f]\t[%f]\t[%f]\n", matrix[0], matrix[1], matrix[2], matrix[3]);
        printf("[%f]\t[%f]\t[%f]\t[%f]\n", matrix[4], matrix[5], matrix[6], matrix[7]);
        printf("[%f]\t[%f]\t[%f]\t[%f]\n", matrix[8], matrix[9], matrix[10], matrix[11]);
        printf("[%f]\t[%f]\t[%f]\t[%f]\n", matrix[12], matrix[13], matrix[14], matrix[15]);
        Sleep(500);
    }
};

void ShowMenu(GLFWwindow* window)
{
    glfwSetWindowAttrib(window, GLFW_MOUSE_PASSTHROUGH, false);
}
void  HideMenu(GLFWwindow* window)
{
    glfwSetWindowAttrib(window, GLFW_MOUSE_PASSTHROUGH, true);
}
void ConvertToRange(Vec2& point,Vec2& res)
{
    point.x /= res.x;
    point.x *= 2.0f;
    point.x -= 1.0f;

    point.y /= res.y;
    point.y *= 2.0f;
    point.y -= 1.0f;
}
bool WorldToScreen(const Vec3& origin, Vec2& screen, float* matrix)
{
    Vec2 _res(800,600);
    screen.x = origin.x * matrix[0] + origin.y * matrix[1] + origin.z * matrix[2] + matrix[3];
    screen.y = origin.x * matrix[4] + origin.y * matrix[5] + origin.z * matrix[6] + matrix[7];
    float w = origin.x * matrix[12] + origin.y * matrix[13] + origin.z * matrix[14] + matrix[15];

    if (w < 0.001f)
        return false;

    Vec2 ndc;
    ndc.x = screen.x / w;
    ndc.y = screen.y / w;

    screen.x = (_res.x / 2 * ndc.x) + (ndc.x + _res.x / 2);
    screen.y = -(_res.y/ 2 * ndc.y) + (ndc.y + _res.y / 2);
    //ConvertToRange(screen,_res);
    return true;
}
static void glfw_error_callback(int error, const char* description)
{
    fprintf(stderr, "GLFW Error %d: %s\n", error, description);
}
 
// Main code
int main(int, char**)
{
    glfwSetErrorCallback(glfw_error_callback);
    if (!glfwInit())
        return 1;
    
    glfwWindowHint(GLFW_FLOATING, true);
    glfwWindowHint(GLFW_RESIZABLE, false);
    glfwWindowHint(GLFW_TRANSPARENT_FRAMEBUFFER, true);
    glfwWindowHint(GLFW_MOUSE_PASSTHROUGH, true);
    glfwWindowHint(GLFW_DECORATED, false);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
 
    // Create window with graphics context
    GLFWwindow* window = glfwCreateWindow(800, 600, "ESP", nullptr, nullptr);
    if (window == nullptr)
        return 1;
    glfwMakeContextCurrent(window);
 

    // Setup Dear ImGui context
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;     // Enable Keyboard Controls

    ImGui::StyleColorsDark();
 
    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init("#version 130");
 
    // Our state
 
    MoveWindow(GetConsoleWindow(), 1500, 0, 450, 400, TRUE);
    HWND FGW = FindWindow(NULL, L"Counter-Strike Source");
 /*   DWORD pid;
    GetWindowThreadProcessId(FGW, &pid);

    HANDLE  gameHandle = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);*/
    MemMan m;
    m.getProcess(L"hl2.exe");
    RECT rect;
    bool showMenu = true;
   
    Matrix matrix;
    DWORD matrixAddress = 0x104FF22C;
    Vec3 Pos(-240.03125f, 2204.063965, -126.03965);
    Vec2 screen;
    while (!glfwWindowShouldClose(window))
 
    {
        GetWindowRect(FGW, &rect);
        glfwSetWindowPos(window, rect.left + 3, rect.top + 26);
        glfwPollEvents();

        // Start the Dear ImGui frame
        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();

        if (GetAsyncKeyState(VK_INSERT) & 1)
        {
            showMenu = !showMenu;
            if (showMenu)
                ShowMenu(window);
            else
                HideMenu(window);
        }
       /* if (showMenu) {            
         
        }*/
       
        matrix = m.readMem<Matrix>(matrixAddress);
        ImGui::Text(std::to_string(WorldToScreen(Pos, screen, matrix.matrix)).c_str());

        ImGui::SetNextWindowPos(ImVec2(0, 0));
        ImGui::SetNextWindowSize(ImVec2(800, 600));
        ImGui::Begin("Overlay", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_NoBackground);

        auto pDrawList = ImGui::GetWindowDrawList();

        //pDrawList->AddRect(ImVec2(10, 10), ImVec2(100, 100), ImColor(255, 0, 0));
        if (WorldToScreen(Pos, screen, matrix.matrix))
        {
            pDrawList->AddLine(ImVec2(800 / 2.f, 600), ImVec2(screen.x, screen.y), ImColor(255, 0, 0));
        }
        //pDrawList->AddText(ImVec2(10, 10), ImColor(255, 0, 0), "test");
 
        ImGui::End();
        // Rendering
        ImGui::Render();
        /*int display_w, display_h;
        glfwGetFramebufferSize(window, &display_w, &display_h);
        glViewport(0, 0, display_w, display_h);*/
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        glfwSwapBuffers(window);
    }
 
    // Cleanup
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();

    glfwDestroyWindow(window);
    glfwTerminate();

    return 0;
}
